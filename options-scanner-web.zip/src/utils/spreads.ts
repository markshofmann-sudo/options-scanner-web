export type CallOption = {
  strike: number
  bid?: number
  ask?: number
  lastPrice?: number
  openInterest?: number
  volume?: number
}

export type SpreadRow = {
  symbol: string
  expiration: string
  long_strike: number
  short_strike: number
  width: number
  long_mid: number
  short_mid: number
  net_premium: number   // negative = credit
  is_credit: boolean
  long_oi: number
  short_oi: number
  long_volume: number
  short_volume: number
}

export function mid(bid?: number, ask?: number, last?: number): number | undefined {
  if (bid && ask && bid > 0 && ask > 0) return (bid + ask) / 2
  if (last && last > 0) return last
  if (bid && bid > 0) return bid
  if (ask && ask > 0) return ask
  return undefined
}

export function buildCallSpreads(
  calls: CallOption[],
  symbol: string,
  expiration: string,
  minOI: number,
  minVol: number
): SpreadRow[] {
  const filtered = calls
    .filter(c => (c.openInterest ?? 0) >= minOI && (c.volume ?? 0) >= minVol)
    .map(c => ({ ...c, _mid: mid(c.bid, c.ask, c.lastPrice) } as any))
    .filter((c: any) => c._mid !== undefined)
    .sort((a:any,b:any)=> a.strike - b.strike)

  const rows: SpreadRow[] = []
  for (let i = 0; i < filtered.length; i++) {
    for (let j = i + 1; j < filtered.length; j++) {
      const lower = filtered[i] as any
      const higher = filtered[j] as any
      const width = higher.strike - lower.strike
      if (width <= 0) continue

      // Bear Call CREDIT: short lower, long higher → net credit (negative net_premium here)
      const shortLower = lower._mid as number
      const longHigher = higher._mid as number
      const net = longHigher - shortLower // negative => credit

      rows.push({
        symbol,
        expiration,
        long_strike: higher.strike,
        short_strike: lower.strike,
        width,
        long_mid: longHigher,
        short_mid: shortLower,
        net_premium: net,
        is_credit: net < 0,
        long_oi: (higher.openInterest ?? 0),
        short_oi: (lower.openInterest ?? 0),
        long_volume: (higher.volume ?? 0),
        short_volume: (lower.volume ?? 0),
      })
    }
  }
  return rows
}

export function pickClosestDates(
  expirations: string[],
  targets = [7,14,30]
): string[] {
  if (!expirations?.length) return []
  const today = new Date()
  const picks: string[] = []
  for (const t of targets) {
    let best: {d: string, diff: number} | null = null
    for (const e of expirations) {
      const dd = Math.ceil((new Date(e).getTime() - today.getTime())/86400000)
      const diff = Math.abs(dd - t)
      if (dd < 0) continue
      if (!best || diff < best.diff) best = { d: e, diff }
    }
    if (best && !picks.includes(best.d)) picks.push(best.d)
  }
  return picks
}
