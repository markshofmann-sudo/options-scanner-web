import type { NextApiRequest, NextApiResponse } from 'next'
import yahooFinance from 'yahoo-finance2'
import { NASDAQ100 } from '@/data/nasdaq100'
import { buildCallSpreads, pickClosestDates, SpreadRow } from '@/utils/spreads'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const tickers = (req.body?.tickers as string[] | undefined) ?? NASDAQ100
    const minOI = Number(req.body?.minOI ?? 50)
    const minVol = Number(req.body?.minVol ?? 1)
    const limit = Number(req.body?.limit ?? 10)

    const top: SpreadRow[] = []

    for (const symbol of tickers) {
      const opt = await yahooFinance.options(symbol, { formatted: false })
      const exps = (opt?.expirationDates ?? []).map((d: any) => new Date(d).toISOString().slice(0,10))
      const targetExps = pickClosestDates(exps, [7,14,30])

      for (const e of targetExps) {
        const chain = await yahooFinance.options(symbol, { date: e, formatted: false })
        const calls = (chain?.calls ?? []).map((c:any)=> ({
          strike: Number(c.strike),
          bid: c.bid,
          ask: c.ask,
          lastPrice: c.lastPrice,
          openInterest: c.openInterest,
          volume: c.volume,
        }))

        const rows = buildCallSpreads(calls, symbol, e, minOI, minVol).filter(r => r.is_credit)
        top.push(...rows)
      }
    }

    const ranked = top.sort((a,b)=> Math.abs(a.net_premium) - Math.abs(b.net_premium) || b.width - a.width)
    const sliced = ranked.slice(0, limit)
    res.status(200).json({ rows: sliced })
  } catch (e:any) {
    res.status(500).json({ error: e?.message || 'scan_failed' })
  }
}
