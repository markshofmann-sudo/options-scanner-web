import React, { useState } from 'react'

export default function Home(){
  const [loading, setLoading] = useState(false)
  const [rows, setRows] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)

  async function onSearch(){
    setLoading(true); setError(null); setRows([])
    try{
      const r = await fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ limit: 10, minOI:50, minVol:1 }) })
      const data = await r.json()
      if(!r.ok){ throw new Error(data?.error || 'Scan failed') }
      setRows(data.rows || [])
    }catch(e:any){ setError(e.message) }
    finally{ setLoading(false) }
  }

  function exportCsv(){
    const header = ['symbol','expiration','long_strike','short_strike','width','long_mid','short_mid','net_premium','is_credit','long_oi','short_oi','long_volume','short_volume']
    const lines = [header.join(',')].concat(rows.map(r=> header.map(h=> r[h]).join(',')))
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'top10_spreads.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen p-6" style={{fontFamily:'Inter, system-ui, sans-serif'}}>
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold">Call Spread Finder (Top 10 · Net Credit Closest to $0)</h1>
        <p className="text-sm text-gray-600 mt-2">Universe: NASDAQ‑100 · Expirations near 7/14/30 days · Filters: OI≥50, Vol≥1</p>

        <div className="mt-6 flex items-center gap-3">
          <button onClick={onSearch} disabled={loading} className="px-4 py-2 rounded-2xl shadow font-medium border">
            {loading? 'Searching…' : 'Search'}
          </button>
          {rows.length>0 && (
            <button onClick={exportCsv} className="px-4 py-2 rounded-2xl shadow font-medium border">Export CSV</button>
          )}
        </div>

        {error && <div className="mt-4 p-3 border text-red-700 bg-red-50 rounded">{error}</div>}

        <div className="mt-6 overflow-auto border rounded-xl">
          <table className="min-w-full" style={{borderCollapse:'collapse'}}>
            <thead>
              <tr className="bg-gray-50">
                {['symbol','expiration','long_strike','short_strike','width','long_mid','short_mid','net_premium','is_credit','long_oi','short_oi','long_volume','short_volume'].map(h=> (
                  <th key={h} className="text-left text-xs font-semibold text-gray-700 px-3 py-2 border-b">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r,i)=> (
                <tr key={i} className="odd:bg-white even:bg-gray-50">
                  {['symbol','expiration','long_strike','short_strike','width','long_mid','short_mid','net_premium','is_credit','long_oi','short_oi','long_volume','short_volume'].map(k=> (
                    <td key={k} className="px-3 py-2 text-sm border-b" style={{fontFamily:'ui-monospace, SFMono-Regular, Menlo, monospace'}}>{String(r[k])}</td>
                  ))}
                </tr>
              ))}
              {(!loading && rows.length===0) && (
                <tr><td className="px-3 py-6 text-sm text-gray-500" colSpan={13}>Click <b>Search</b> to fetch the Top 10.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <p className="text-xs text-gray-500 mt-3">Data via Yahoo Finance (yahoo-finance2). Research use only — verify prices/liquidity with your broker.</p>
      </div>
    </div>
  )
}
